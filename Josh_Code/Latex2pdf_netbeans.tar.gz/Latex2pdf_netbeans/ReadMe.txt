1) We have developed module for netbeans.
2) When we click on the icon(face) a windows asks to browse and select the file we want to convert from Latex to pdf.The selected file file_name.tex is    	converted to file_name.pdf in the same directory as .tex  file.
3) The pdf file can then even be used further down the line in the program.

