/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.orgtest.test;

import java.awt.Image;
import java.io.*;
import javax.swing.JFileChooser;
import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;
import org.openide.DialogDisplayer;
import org.openide.NotifyDescriptor;

public final class TestAction extends CallableSystemAction {

    public void performAction(){
        String msg = "The file has been saved by name ";
        String filename = "";
        try {
            String wd = System.getProperty("user.dir");
            JFileChooser fc = new JFileChooser(wd);
            int rc = fc.showDialog(null, "Select Latex File");
            if (rc == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                filename = file.getCanonicalPath();
            }else {
                return;
            }
        }
        catch (IOException exc) {
            exc.printStackTrace ();
        }
        
       String args [] = {"pdflatex", filename};
        try {
           Runtime runtime = Runtime.getRuntime();
           runtime.exec(args);
        }catch (IOException exc) {
            exc.printStackTrace();
        }
       
        String temp = filename.substring(1, filename.length() - 3);
        temp += "pdf";
        while (temp.indexOf('/') != -1) {
            temp = temp.substring(1, temp.length());
        }
        //NotifyDescriptor d = new NotifyDescriptor.Message(temp, NotifyDescriptor.INFORMATION_MESSAGE);
        //DialogDisplayer.getDefault().notify(d);
        String initialFilename = temp;
       
        try {
            String wd = System.getProperty("user.dir");
            JFileChooser fc = new JFileChooser(wd);
            int rc = fc.showDialog(null, "Select Latex File");
            if (rc == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                filename = file.getCanonicalPath();
            }
        }
        catch (IOException exc) {
            exc.printStackTrace ();
        }
       args = new String [4];
       args [0] = "mv";
       args [1] = "-f";
       args [2] = initialFilename;
       args [3] = filename;
        try {
           Runtime runtime = Runtime.getRuntime();
           runtime.exec(args);
        }catch (IOException exc) {
            exc.printStackTrace();
        }
        
        NotifyDescriptor d1 = new NotifyDescriptor.Message(msg + filename, NotifyDescriptor.INFORMATION_MESSAGE);
        DialogDisplayer.getDefault().notify(d1);
    }

    public String getName() {
        
        return NbBundle.getMessage(TestAction.class, "CTL_TestAction");
    }

    @Override
    protected String iconResource() {
        return "org/orgtest/test/icon.png";
    }

    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }

    @Override
    protected boolean asynchronous() {
        return false;
    }
}
