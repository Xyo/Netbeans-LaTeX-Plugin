/*
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.idrsolutions.com
 * Help section for developers at http://www.idrsolutions.com/support/
 *
 * (C) Copyright 1997-2016 IDRsolutions and Contributors.
 *
 * This file is part of JPedal/JPDF2HTML5
 *
 @LICENSE@
 *
 * ---------------
 * SwingHelper.java
 * ---------------
 */
package org.jpedal.display.swing;

import java.awt.Graphics2D;

@SuppressWarnings("ALL")
public class SwingHelper {
  
    public static void scaleDisplay(Graphics2D g2, int crx, int cry, int crw, int crh) {
        //   throw new UnsupportedOperationException("Not supported yet."); 
    }
}