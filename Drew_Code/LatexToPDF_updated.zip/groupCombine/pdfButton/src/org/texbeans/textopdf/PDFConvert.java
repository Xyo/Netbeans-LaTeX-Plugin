/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.texbeans.textopdf;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import javax.swing.JFileChooser;
import javax.tools.FileObject;
import org.latex.filetype.TexDataObject;
import org.openide.*;
import org.openide.awt.ActionID;
import org.openide.awt.ActionReference;
import org.openide.awt.ActionRegistration;
import org.openide.filesystems.FileUtil;
import org.openide.loaders.DataObject;
import org.openide.util.Exceptions;
import org.openide.util.HelpCtx;
import org.openide.util.Lookup;
import org.openide.util.NbBundle;
import org.openide.util.NbBundle.Messages;
import org.openide.util.Utilities;
import org.openide.util.actions.CallableSystemAction;

@ActionID(
        category = "Bugtracking",
        id = "org.texbeans.textopdf.PDFConvert"
)
@ActionRegistration(
        iconBase = "org/texbeans/textopdf/logo.png",
        displayName = "#CTL_PDFConvert"
)
@ActionReference(path = "Toolbars/Build", position = 250)
@Messages("CTL_PDFConvert=Latex to PDF")
public final class PDFConvert implements ActionListener {


    TexDataObject context;

    public PDFConvert(DataObject context) {
        this.context = (TexDataObject) context;
    }

    @Override
    public void actionPerformed(ActionEvent ev) {
        TexDataObject tobj = Utilities.actionsGlobalContext().lookup(TexDataObject.class);                      

                //String message = FileUtil.toFile(tobj.getPrimaryFile()).getAbsolutePath();
                //NotifyDescriptor nd = new NotifyDescriptor.Message(message);
                //DialogDisplayer.getDefault().notify(nd);
 
            /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

        String msg = "The file has been saved by name ";
        String filename = "";
        //try {
        //    String wd = System.getProperty("user.dir");
        //    JFileChooser fc = new JFileChooser(wd);
        //    int rc = fc.showDialog(null, "Select Latex File");
        //    if (rc == JFileChooser.APPROVE_OPTION) {
        //        File file = fc.getSelectedFile();
                filename = FileUtil.toFile(tobj.getPrimaryFile()).getAbsolutePath();
        //    }else {
        //        return;
        //    }
        //}
        //catch (IOException exc) {
        //    exc.printStackTrace ();
        //}
        
       String args [] = {"pdflatex", filename};
        try {
           Runtime runtime = Runtime.getRuntime();
           runtime.exec(args);
        }catch (IOException exc) {
            exc.printStackTrace();
        }
       
        String temp = filename.substring(1, filename.length() - 3);
        temp += "pdf";
        while (temp.indexOf('/') != -1) {
            temp = temp.substring(1, temp.length());
        }
        //NotifyDescriptor d = new NotifyDescriptor.Message(temp, NotifyDescriptor.INFORMATION_MESSAGE);
        //DialogDisplayer.getDefault().notify(d);
        String initialFilename = temp;
       
       args = new String [4];
       args [0] = "mv";
       args [1] = "-f";
       args [2] = initialFilename;
       args [3] = filename;
        try {
           Runtime runtime = Runtime.getRuntime();
           runtime.exec(args);
        }catch (IOException exc) {
            exc.printStackTrace();
        }
        
        NotifyDescriptor d1 = new NotifyDescriptor.Message(msg + filename, NotifyDescriptor.INFORMATION_MESSAGE);
        DialogDisplayer.getDefault().notify(d1);
    }

    public String getName() {
        
        return NbBundle.getMessage(MenuConvertToPDF.class, "CTL_TestAction");
    }

    //@Override
    //protected String iconResource() {
    //    return "org/orgtest/test/icon.png";
    //}

    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }

    //@Override
    //protected boolean asynchronous() {
    //    return false;
    //}

    
}
